import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:marketApp/widgts/buttonWidght.dart';

class IntroScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFdfddcc),
      body: Center(

        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 20,vertical: 30
          ),
          child: Column(

            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
             SizedBox(),
              Image.asset('assets/imgs/logomarket.png'),

              ButtonWidght(text: 'هيا بنا لنبدأ',
                onPressed: (){Navigator.of(context).pushNamed('login');},
                bgColor: 0xFF7c7c73,
                textColor: Colors.white,
              ),
              // some code here ...
            ],
          ),
        ),
      ),
    );
  }
}
