import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
  //
  // class UserApp {
  //   final String uid ,stm;
  //   UserApp({@required this.uid,this.stm});
  // }
  //
  // class AuthBase {
  //   UserApp _userFromFirebase(User user ,{String stm}) {
  //     return user != null ? UserApp(uid: user.uid)
  //         : UserApp(uid: user.uid,stm: stm) ;
  //   }
  //
  //   Future<void> registerWithEmailAndPassword(
  //       String email, String password) async {
  //     try {
  //       final authResult = await FirebaseAuth.instance
  //           .createUserWithEmailAndPassword(email: email, password: password);
  //       if(authResult!=null)
  //       return _userFromFirebase(authResult.user);
  //       else return _userFromFirebase(authResult.user,stm: 'no user');
  //     } catch (e) {
  //       print(e.toString());
  //       return null;
  //     }
  //   }
  //
  //   Future<void> loginWithEmailAndPassword(String email, String password) async {
  //     try {
  //       final authResult = await FirebaseAuth.instance
  //           .signInWithEmailAndPassword(email: email, password: password);
  //       return _userFromFirebase(authResult.user);
  //     } catch (e) {
  //       print(e.toString());
  //       return null;
  //     }
  //   }
  //
  //   Future<void> logout() async {
  //     await FirebaseAuth.instance.signOut();
  //   }
  // }
