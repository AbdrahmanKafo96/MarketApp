import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'authentication.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
 // AuthBase authBase = AuthBase();

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('تطبيق محل'),
    actions: [
      IconButton(icon: Icon(Icons.logout), onPressed: (){
        FirebaseAuth.instance.signOut();
        Navigator.of(context).pushReplacementNamed('login');
      }
      )
    ],
    ),);
  }
}
