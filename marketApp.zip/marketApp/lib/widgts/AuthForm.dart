 import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:marketApp/DartFiles/auth_screen.dart';
 import 'package:cloud_firestore/cloud_firestore.dart';

import 'buttonWidght.dart';

class AuthForm extends StatefulWidget {
  final AuthType authType;

  const AuthForm({Key key, @required this.authType}) : super(key: key);

  @override
  _AuthFormState createState() => _AuthFormState();
}

class _AuthFormState extends State<AuthForm> {
  //AuthBase authBase = AuthBase();
  @override
  void initState() {
    super.initState();
    Firebase.initializeApp().whenComplete(() {
      print("completed");
      setState(() {});
    });
  }
  final _formKey = GlobalKey<FormState>();
  String _email = "", _password;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          children: [
            SizedBox(
              height: 16,
            ),
            TextFormField(
              onChanged: (value) => _email = value,
              validator: (value) =>
                  value.isEmpty ? 'من فضلك ادخل بريد صالح' : null,
              decoration: InputDecoration(
                  labelText: "قم بإدخال البريد الإلكتروني",
                  hintText: "example@example.com"),
            ),
            SizedBox(
              height: 12,
            ),
            TextFormField(
              onChanged: (value) => _password = value,
              validator: (value) =>
                  value.length < 6 ? "من فضلك تأكد من الرمز" : null,
              decoration: InputDecoration(
                labelText: "قم بإدخال الرمز السري",
              ),
              obscureText: true,
            ),
            // widget.authType == AuthType.register
            //     ? TextFormField(
            //         onChanged: (value) => _email = value,
            //         validator: (value) =>
            //             value.isEmpty ? 'من فضلك ادخل بريد صالح' : null,
            //         decoration: InputDecoration(
            //             labelText: "قم بإدخال البريد الإلكتروني",
            //             hintText: "example@example.com"),
            //       )
            //     : SizedBox.shrink(),
            SizedBox(
              height: 20,
            ),
            ButtonWidght(
              text: widget.authType == AuthType.login
                  ? 'تسجيل الدخول'
                  : 'إنشاء حساب',
              onPressed: () async {
                if (_formKey.currentState.validate())
                {var result;
                  if (widget.authType == AuthType.login){
                    try{
                      result=await FirebaseAuth.instance
                          .signInWithEmailAndPassword(email: _email, password: _password);
                      if(result!=null) {
                        // var userInfo=FirebaseFirestore.instance.collection("users")
                        //     .doc().set({
                        //   "username":"abdokafo"
                        // });
                        Navigator.of(context).pushReplacementNamed('Home');
                      }
                    }catch(e){
                      print("the message e =${e}");
                    }
                  }

                  else {

                    result=await FirebaseAuth.instance.
                    createUserWithEmailAndPassword(email: _email, password: _password);
                    if(result !=null)
                    Navigator.of(context).pushReplacementNamed('Home');
                  }
                }
                },
              textColor: Colors.white,
              bgColor: 0xFF7c7c73,
            ),
            SizedBox(
              height: 5,
            ),
            FlatButton(
              onPressed: () {
                if (widget.authType == AuthType.login)
                  Navigator.of(context).pushReplacementNamed('register');
                else
                  Navigator.of(context).pushReplacementNamed('login');
              },
              child: Text(
                widget.authType == AuthType.login
                    ? "ليس لذيك حساب ؟سجل معنا"
                    : 'هل انت تملك حساب؟',
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: 18,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
