import 'package:flutter/material.dart';
import 'package:marketApp/DartFiles/HomeScreen.dart';
 import 'package:marketApp/Dartfiles/IntroScreen.dart';

import 'DartFiles/auth_screen.dart';


  void main() {
    runApp( StartApp());
  }
  class StartApp extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
      return  MaterialApp(
        debugShowCheckedModeBanner: false,
        title:'market App' ,
        theme: ThemeData(
          hintColor: Colors.grey,
          inputDecorationTheme: InputDecorationTheme(
            fillColor: Color(0xfff2f9fe),
            filled: true,
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey[400]),
              borderRadius: BorderRadius.circular(25),
            ),
            disabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey[400]),
              borderRadius: BorderRadius.circular(25),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey[400]),
              borderRadius: BorderRadius.circular(25),
            ),
          ),
        ),
        home:IntroScreen() ,
        routes: {
          'login':(context) => AuthScreen(authType:AuthType.login),
          'register':(context) => AuthScreen(authType:AuthType.register),
          'Home':(context) =>HomeScreen(),

        },
      );
    }
  }


